import React, { Component } from 'react';
import '../component/HelloComponent.css';

class Hello extends Component {
            
    render() { 
        return (
            <div className='Hello'>
             <p className='text-p'> ini adalah arrow function yang ada di folder</p>
            </div>
        )
    }
}
export default Hello;